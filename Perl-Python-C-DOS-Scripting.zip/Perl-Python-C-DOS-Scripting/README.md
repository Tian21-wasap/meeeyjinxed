# Perl

A group of basic DOS scripts for perl. Enjoy <3
